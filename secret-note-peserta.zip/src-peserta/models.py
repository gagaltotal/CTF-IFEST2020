from app import db


class Users(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(255))
    email = db.Column(db.String(255))
    password = db.Column(db.String(255))

    def __init__(self, username, email, password):
        self.username = username
        self.email = email
        self.password = password

    @staticmethod
    def check_email(email):
        email = Users.query.filter_by(email=email).first()

        if email is None:
            return False
        return True

    @staticmethod
    def login(email, password):
        pass

    def to_dict(self):
        return {"id" : self.id, "username" : self.username, "email" : self.email, "password" : self.password}

class Secrets(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    secret_owner = db.Column(db.Integer)
    content = db.Column(db.Text)
    create_on = None
    
    def __init__(self, secret_owner, content):
        self.secret_owner = secret_owner
        self.content = content

    def to_dict(self):
        return {"id" : self.id, "secret_owner" : self.secret_owner, "content" : self.content, "create_on" : self.create_on}
